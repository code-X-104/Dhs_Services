const LANGUAGES = {
  en: {
    title: "📦 Goods Tracking System",
    prompt: "Enter your tracking number:",
    button: "Track",
    notFound: "Tracking number not found.",
    error: "Error loading tracking data.",
    heading: id => `Tracking Info for ${id}`,
    item: "Item",
    status: "Status",
    location: "Location",
    updated: "Last Updated"
  },
  de: {
    title: "📦 Sendungsverfolgungssystem",
    prompt: "Gib deine Sendungsnummer ein:",
    button: "Verfolgen",
    notFound: "Sendungsnummer nicht gefunden.",
    error: "Fehler beim Laden der Daten.",
    heading: id => `Sendungsdetails für ${id}`,
    item: "Artikel",
    status: "Status",
    location: "Standort",
    updated: "Zuletzt aktualisiert"
  }
};

function getQueryParam(param) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(param);
}

async function track(optionalId = null) {
  const id = (optionalId || document.getElementById("trackingId").value).trim().toUpperCase();
  const result = document.getElementById("result");

  document.getElementById("trackingId").value = id;

  try {
    const response = await fetch("data.json");
    const trackingData = await response.json();
    const info = trackingData[id];

    if (info) {
      result.innerHTML = `
        <h4>${lang.heading(id)}</h4>
        <p><strong>${lang.item}:</strong> ${info.item}</p>
        <p><strong>${lang.status}:</strong> ${info.status}</p>
        <p><strong>${lang.location}:</strong> ${info.location}</p>
        <p><strong>${lang.updated}:</strong> ${info.updated}</p>
      `;
    } else {
      result.innerHTML = `<p style="color:red;">${lang.notFound}</p>`;
    }
  } catch (err) {
    result.innerHTML = `<p style="color:red;">${lang.error}</p>`;
  }
}

let lang = LANGUAGES.en;
window.onload = () => {
  const langCode = getQueryParam("lang");
  const idFromURL = getQueryParam("id");

  if (LANGUAGES[langCode]) {
    lang = LANGUAGES[langCode];
  }

  document.querySelector("h2").textContent = lang.title;
  document.querySelector("p").textContent = lang.prompt;
  document.querySelector("button").textContent = lang.button;

  if (idFromURL) {
    track(idFromURL);
  }
};
